import React, { useState, useEffect } from 'react';
import {
    Box,
    Container,
    Typography,
    Alert,
    Snackbar,
    CircularProgress,
    Button,
    Card,
    CardContent,
    Divider,
    TextField,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Tab,
    Tabs,
    Chip,
    Drawer,
    IconButton,
    useMediaQuery,
    useTheme
} from '@mui/material';
import {
    Timeline,
    TimelineItem,
    TimelineSeparator,
    TimelineConnector,
    TimelineContent,
    TimelineDot,
    TimelineOppositeContent
} from '@mui/lab';
import { useParams, useNavigate } from 'react-router-dom';
import {
    Edit as EditIcon,
    ArrowBack as ArrowBackIcon,
    Assessment as AssessmentIcon,
    History as HistoryIcon,
    Menu as MenuIcon,
    Close as CloseIcon,
    Delete as DeleteOutline,
    Download as DownloadIcon
} from '@mui/icons-material';
import AssessmentSummary from '../../Components/ArchitectureAssessment/AssessmentSummary';
import AssessmentForm from '../../Components/ArchitectureAssessment/AssessmentForm';
import AssessmentHistoryList from '../../Components/ArchitectureAssessment/History/AssessmentHistoryList';
import AssessmentDashboard from '../../Components/ArchitectureAssessment/Dashboard/AssessmentDashboard';
import VulnerabilityManager from '../../Components/ArchitectureAssessment/Vulnerability/VulnerabilityManager';
import {
    fetchAssessments,
    fetchAssessmentDetails,
    updateAssessment,
    deleteAssessment,
    downloadReport,
    fetchAssessmentHistory
} from '../../api/architectureAssessmentService';

const ArchitectureAssessmentPage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('md'));

    // UI State
    const [sidebarOpen, setSidebarOpen] = useState(!isMobile);
    const [viewMode, setViewMode] = useState('dashboard'); // dashboard, create, details
    const [currentTab, setCurrentTab] = useState(0);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

    // Content-specific state
    const [editDialogOpen, setEditDialogOpen] = useState(false);
    const [editableFields, setEditableFields] = useState({});

    // Data State
    const [assessments, setAssessments] = useState([]);
    const [selectedAssessmentId, setSelectedAssessmentId] = useState(null);
    const [assessmentDetails, setAssessmentDetails] = useState(null);
    const [assessmentHistory, setAssessmentHistory] = useState([]); // New state for history
    const [loading, setLoading] = useState({
        list: true,
        details: false,
        action: false,
        history: false // loading state for history
    });

    // Initial Load
    useEffect(() => {
        loadAssessments();
    }, []);

    // Handle URL param changes
    useEffect(() => {
        if (id) {
            setSelectedAssessmentId(id);
            setViewMode('details');
            loadAssessmentDetails(id);
        } else if (window.location.pathname.endsWith('/create')) { // Optional: handle direct /create route
            setViewMode('create');
            setSelectedAssessmentId(null);
        } else {
            setViewMode('dashboard');
            setSelectedAssessmentId(null);
        }
    }, [id]);

    const loadAssessments = async () => {
        setLoading(prev => ({ ...prev, list: true }));
        try {
            const data = await fetchAssessments();
            setAssessments(data);
        } catch (error) {
            showSnackbar('Failed to load assessments history', 'error');
        } finally {
            setLoading(prev => ({ ...prev, list: false }));
        }
    };

    const loadAssessmentDetails = async (calcId) => {
        if (!calcId) return;
        setLoading(prev => ({ ...prev, details: true, history: true }));
        try {
            const [detailsData, historyData] = await Promise.all([
                fetchAssessmentDetails(calcId),
                fetchAssessmentHistory(calcId)
            ]);

            setAssessmentDetails(detailsData);
            setAssessmentHistory(historyData);

            setEditableFields({
                application_purpose: detailsData.application_purpose || '',
                business_objectives: detailsData.business_objectives || '',
                stakeholders: detailsData.stakeholders || '',
                system_owners: detailsData.system_owners || '',
                compliance_requirements: detailsData.compliance_requirements || ''
            });
        } catch (error) {
            showSnackbar('Failed to load assessment details', 'error');
            setViewMode('dashboard');
        } finally {
            setLoading(prev => ({ ...prev, details: false, history: false }));
        }
    };

    // Actions
    const handleCreateNew = () => {
        setSelectedAssessmentId(null);
        setViewMode('create');
        if (isMobile) setSidebarOpen(false);
        navigate('/architecture-assessment');
    };

    const handleSelectAssessment = (newId) => {
        setSelectedAssessmentId(newId);
        navigate(`/architecture-assessment/${newId}`);
        if (isMobile) setSidebarOpen(false);
    };

    const handleDeleteAssessment = async (deleteId) => {
        if (!window.confirm('Are you sure you want to delete this assessment?')) return;

        try {
            await deleteAssessment(deleteId);
            showSnackbar('Assessment deleted successfully');
            loadAssessments();
            if (selectedAssessmentId === deleteId) {
                setViewMode('dashboard');
                navigate('/architecture-assessment');
            }
        } catch (error) {
            showSnackbar('Failed to delete assessment', 'error');
        }
    };

    const handleDownloadReport = async (downloadId) => {
        try {
            const blob = await downloadReport(downloadId);
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `assessment-report-${downloadId}.xlsx`; // Or however api returns filename
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            showSnackbar('Failed to download report', 'error');
        }
    };

    const showSnackbar = (message, severity = 'success') => {
        setSnackbar({ open: true, message, severity });
    };

    const handleUpdateVulnerability = (updatedVuln) => {
        // Update local state to reflect changes immediately
        if (assessmentDetails) {
            const updatedVulns = assessmentDetails.vulnerable_components.map(v =>
                v.id === updatedVuln.id ? updatedVuln : v
            );
            setAssessmentDetails({ ...assessmentDetails, vulnerable_components: updatedVulns });
        }
    };

    const handleSaveEdit = async () => {
        if (!selectedAssessmentId) return;
        try {
            const updated = await updateAssessment(selectedAssessmentId, editableFields);
            setAssessmentDetails(prev => ({ ...prev, ...updated }));
            setEditDialogOpen(false);
            showSnackbar('Assessment updated successfully');
            // Update list as well since purpose might have changed
            loadAssessments();
        } catch (error) {
            showSnackbar('Failed to update assessment details', 'error');
        }
    };

    // Render Helpers
    const renderSidebar = () => (
        <AssessmentHistoryList
            assessments={assessments}
            loading={loading.list}
            selectedId={selectedAssessmentId}
            onSelect={handleSelectAssessment}
            onCreateNew={handleCreateNew}
            onDelete={handleDeleteAssessment}
            onDownload={handleDownloadReport}
        />
    );

    const renderMainContent = () => {
        if (viewMode === 'dashboard') {
            return (
                <AssessmentDashboard onCreateNew={handleCreateNew} />
            );
        }

        if (viewMode === 'create') {
            return (
                <Box sx={{ p: 3, bgcolor: '#111827', minHeight: '100%' }}>
                    <Button
                        startIcon={<ArrowBackIcon />}
                        onClick={() => { setViewMode('dashboard'); navigate('/architecture-assessment'); }}
                        sx={{ mb: 2, color: 'gray.300' }}
                    >
                        Back to Dashboard
                    </Button>
                    <AssessmentForm />
                </Box>
            );
        }

        // Details View
        if (loading.details) {
            return (
                <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', bgcolor: '#111827' }}>
                    <CircularProgress />
                </Box>
            );
        }

        if (!assessmentDetails) return null;

        const vulnerableComponents = assessmentDetails.vulnerable_components || [];
        const history = assessmentHistory || [];

        return (
            <Box sx={{ bgcolor: '#111827', minHeight: '100vh', color: 'white', pb: 4 }}>
                <Container maxWidth="xl" sx={{ pt: 4 }}>
                    {/* Header Action Bar */}
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                        <Button
                            startIcon={<ArrowBackIcon />}
                            onClick={() => { setViewMode('dashboard'); navigate('/architecture-assessment'); }}
                            sx={{ color: 'gray.300' }}
                        >
                            Dashboard
                        </Button>
                        <Box sx={{ display: 'flex', gap: 2 }}>
                            <Button
                                variant="outlined"
                                startIcon={<DownloadIcon />}
                                onClick={() => handleDownloadReport(assessmentDetails.id)}
                                sx={{ color: '#3b82f6', borderColor: '#3b82f6' }}
                            >
                                Report
                            </Button>
                            <Button
                                variant="outlined"
                                startIcon={<EditIcon />}
                                onClick={() => setEditDialogOpen(true)}
                                sx={{ color: '#f59e0b', borderColor: '#f59e0b' }}
                            >
                                Edit Details
                            </Button>
                            <Button
                                variant="outlined"
                                startIcon={<DeleteOutline />}
                                onClick={() => handleDeleteAssessment(assessmentDetails.id)}
                                color="error"
                            >
                                Delete
                            </Button>
                        </Box>
                    </Box>

                    {/* Summary Card */}
                    <AssessmentSummary assessment={assessmentDetails} />

                    {/* Tabs */}
                    <Card sx={{ bgcolor: '#1f2937', border: '1px solid #374151', mt: 3 }}>
                        <Tabs
                            value={currentTab}
                            onChange={(e, v) => setCurrentTab(v)}
                            textColor="inherit"
                            indicatorColor="primary"
                            sx={{ borderBottom: '1px solid #374151', '& .MuiTab-root': { color: 'gray.300' } }}
                        >
                            <Tab label={`Vulnerabilities (${vulnerableComponents.length})`} icon={<AssessmentIcon />} iconPosition="start" />
                            <Tab label={`History (${history.length})`} icon={<HistoryIcon />} iconPosition="start" />
                            {assessmentDetails.architecture_diagram && <Tab label="Architecture Diagram" icon={<AssessmentIcon />} iconPosition="start" />}
                        </Tabs>

                        <Box sx={{ p: 3 }}>
                            {currentTab === 0 && (
                                <Box>
                                    {vulnerableComponents.length > 0 ? (
                                        vulnerableComponents.map((vuln) => (
                                            <VulnerabilityManager
                                                key={vuln.id}
                                                vulnerability={vuln}
                                                onUpdate={handleUpdateVulnerability}
                                            />
                                        ))
                                    ) : (
                                        <Alert severity="info" sx={{ bgcolor: '#064e3b', color: '#a7f3d0' }}>
                                            No vulnerabilities found.
                                        </Alert>
                                    )}
                                </Box>
                            )}

                            {currentTab === 1 && (
                                <Box>
                                    {history.length > 0 ? (
                                        <Timeline position="alternate">
                                            {history.map((item, index) => (
                                                <TimelineItem key={index}>
                                                    <TimelineOppositeContent color="gray.400">
                                                        {new Date(item.timestamp).toLocaleString()}
                                                    </TimelineOppositeContent>
                                                    <TimelineSeparator>
                                                        <TimelineDot color={
                                                            item.action === 'created' ? 'primary' :
                                                                item.action === 'updated' ? 'info' :
                                                                    item.action === 'completed' ? 'success' :
                                                                        'grey'
                                                        } />
                                                        {index < history.length - 1 && <TimelineConnector />}
                                                    </TimelineSeparator>
                                                    <TimelineContent>
                                                        <Typography variant="h6" color="white">
                                                            {item.action}
                                                        </Typography>
                                                        <Typography color="gray.400">
                                                            {item.description}
                                                        </Typography>
                                                        {item.user && (
                                                            <Chip label={`by ${item.user}`} size="small" sx={{ mt: 1, bgcolor: '#374151', color: 'white' }} />
                                                        )}
                                                    </TimelineContent>
                                                </TimelineItem>
                                            ))}
                                        </Timeline>
                                    ) : (
                                        <Typography color="gray.400" align="center">No history available.</Typography>
                                    )}
                                </Box>
                            )}

                            {currentTab === 2 && assessmentDetails.architecture_diagram && (
                                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                                    <Box
                                        component="img"
                                        src={assessmentDetails.architecture_diagram}
                                        alt="Architecture Diagram"
                                        sx={{
                                            maxWidth: '100%',
                                            maxHeight: 600,
                                            objectFit: 'contain',
                                            borderRadius: 2,
                                            border: '1px solid #374151'
                                        }}
                                    />
                                </Box>
                            )}
                        </Box>
                    </Card>
                </Container>
            </Box>
        );
    };

    return (
        <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden', bgcolor: '#111827' }}>
            {/* Mobile Sidebar Toggle */}
            {isMobile && !sidebarOpen && (
                <IconButton
                    onClick={() => setSidebarOpen(true)}
                    sx={{ position: 'absolute', top: 10, left: 10, zIndex: 1200, color: 'white', bgcolor: '#1f2937' }}
                >
                    <MenuIcon />
                </IconButton>
            )}

            {/* Sidebar */}
            <Drawer
                variant={isMobile ? "temporary" : "permanent"}
                open={sidebarOpen}
                onClose={() => setSidebarOpen(false)}
                sx={{
                    width: 320,
                    flexShrink: 0,
                    '& .MuiDrawer-paper': {
                        width: 320,
                        boxSizing: 'border-box',
                        bgcolor: '#1f2937',
                        borderRight: '1px solid #374151'
                    },
                }}
            >
                {renderSidebar()}
            </Drawer>

            {/* Main Content */}
            <Box component="main" sx={{ flexGrow: 1, overflow: 'auto', position: 'relative' }}>
                {renderMainContent()}
            </Box>

            {/* Edit Dialog */}
            <Dialog open={editDialogOpen} onClose={() => setEditDialogOpen(false)} maxWidth="md" fullWidth
                PaperProps={{ sx: { bgcolor: '#1f2937', color: 'white', border: '1px solid #374151' } }}
            >
                <DialogTitle sx={{ borderBottom: '1px solid #374151' }}>Edit Assessment Details</DialogTitle>
                <DialogContent sx={{ pt: 3 }}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
                        {/* Reuse logic for editable fields but style them dark */}
                        {Object.keys(editableFields).map(field => (
                            <TextField
                                key={field}
                                label={field.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                fullWidth
                                multiline={['business_objectives', 'compliance_requirements', 'application_purpose'].includes(field)}
                                rows={2}
                                value={editableFields[field]}
                                onChange={(e) => setEditableFields({ ...editableFields, [field]: e.target.value })}
                                sx={{
                                    '& .MuiInputLabel-root': { color: 'gray.400' },
                                    '& .MuiOutlinedInput-root': { color: 'white', '& fieldset': { borderColor: '#4b5563' } }
                                }}
                            />
                        ))}
                    </Box>
                </DialogContent>
                <DialogActions sx={{ borderTop: '1px solid #374151', p: 2 }}>
                    <Button onClick={() => setEditDialogOpen(false)} sx={{ color: 'gray.300' }}>Cancel</Button>
                    <Button onClick={handleSaveEdit} variant="contained" sx={{ bgcolor: '#2563eb' }}>Save Changes</Button>
                </DialogActions>
            </Dialog>

            <Snackbar
                open={snackbar.open}
                autoHideDuration={6000}
                onClose={() => setSnackbar({ ...snackbar, open: false })}
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            >
                <Alert
                    onClose={() => setSnackbar({ ...snackbar, open: false })}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </Box>
    );
};

export default ArchitectureAssessmentPage;
